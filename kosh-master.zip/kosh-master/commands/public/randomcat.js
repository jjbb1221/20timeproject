Discord.on('message', function (message) {
		if (message.content.startsWith('/randomcat') && true){
 const randomcat = 'https://i.imgur.com/jjqKt7t.gifv';
   return message.reply(`Found you this random cat: ${randomcat}`) }
	return randomcat
 return 'hi'
