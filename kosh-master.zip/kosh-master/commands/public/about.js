Discord.on('message', 	function(message) {
    if (msg.content === '/about') {
        return message.reply('Kosh is a moderation and fun bot perfect for your server!');
