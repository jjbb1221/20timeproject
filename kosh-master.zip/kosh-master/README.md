# Toasty Giveaways
Toasty Giveaways is a discord server that gives free stuff,
this is just our server bot... nothing special.
